import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class CalculatorDemo extends StatefulWidget {
  const CalculatorDemo({Key? key}) : super(key: key);
  @override
  _CalculatorDemoState createState() => _CalculatorDemoState();
}
class _CalculatorDemoState extends State<CalculatorDemo> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}